Changes the Death Texts to be incredibly NSFW and filled with gore, non-con, and other terrible things.
Your character will be terribly mistreated. Not for the faint of heart, but good for those who are depraved.

Not guaranteed to work with other text mods.

Works with mod loaders.

CHANGE LOG

1.2.0: Changed some Death Quotes to be more fitting, and/or more gruesome.

1.1.0: Fixed some spelling and grammar errors, changed some Death Quotes to be more fitting or gruesome.

1.0.0: Mod Uploaded.